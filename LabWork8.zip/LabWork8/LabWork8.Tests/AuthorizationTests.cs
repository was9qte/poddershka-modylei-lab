using System.IO;
using System.Drawing.Imaging;
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Input;
using FlaUI.UIA3;
using FluentAssertions;
using Xunit;

namespace LabWork8.Tests;

public sealed class AuthorizationTests : IDisposable
{
    private readonly Application _app;
    private readonly UIA3Automation _automation;

    public AuthorizationTests()
    {
        var applicationPath = Path.Combine(AppContext.BaseDirectory, "LabWork8.App.exe");
        _app = Application.Launch(applicationPath);
        _automation = new UIA3Automation();
    }

    [Fact]
    public void AdminCredentials_ShowAdministratorWelcome()
    {
        RunAndCapture(nameof(AdminCredentials_ShowAdministratorWelcome), () =>
        {
            FindByAutomationId("LoginField").AsTextBox().Enter("admin");
            EnterPassword("admin123");
            FindByText("Войти").Click();

            FindByAutomationId("WelcomeMessage").Name
                .Should().Be("Добро пожаловать, admin, ваша роль - Администратор");
        });
    }

    [Fact]
    public void StudentCredentials_ShowStudentWelcome()
    {
        RunAndCapture(nameof(StudentCredentials_ShowStudentWelcome), () =>
        {
            FindByName("LoginInput").AsTextBox().Enter("student");
            EnterPassword("student123");
            FindByText("Войти").Click();

            FindByAutomationId("WelcomeMessage").Name
                .Should().Be("Добро пожаловать, student, ваша роль - Студент");
        });
    }

    [Fact]
    public void EmptyLogin_ShowsLoginRequiredError()
    {
        RunAndCapture(nameof(EmptyLogin_ShowsLoginRequiredError), () =>
        {
            EnterPassword("admin123");
            FindByText("Войти").Click();

            FindByAutomationId("ErrorMessage").Name.Should().Be("Введите логин.");
        });
    }

    [Fact]
    public void EmptyPassword_ShowsPasswordRequiredError()
    {
        RunAndCapture(nameof(EmptyPassword_ShowsPasswordRequiredError), () =>
        {
            FindByAutomationId("LoginField").AsTextBox().Enter("admin");
            FindByText("Войти").Click();

            FindByAutomationId("ErrorMessage").Name.Should().Be("Введите пароль.");
        });
    }

    [Fact]
    public void UnknownLogin_ShowsUserNotFoundError()
    {
        RunAndCapture(nameof(UnknownLogin_ShowsUserNotFoundError), () =>
        {
            FindByName("LoginInput").AsTextBox().Enter("unknown");
            EnterPassword("some-password");
            FindByText("Войти").Click();

            FindByAutomationId("ErrorMessage").Name
                .Should().Be("Пользователь с таким логином не найден.");
        });
    }

    [Fact]
    public void IncorrectPassword_ShowsInvalidPasswordError()
    {
        RunAndCapture(nameof(IncorrectPassword_ShowsInvalidPasswordError), () =>
        {
            FindByAutomationId("LoginField").AsTextBox().Enter("admin");
            EnterPassword("wrong-password");
            FindByText("Войти").Click();

            FindByAutomationId("ErrorMessage").Name.Should().Be("Неверный пароль.");
        });
    }

    public void Dispose()
    {
        try
        {
            _app.Close();
        }
        finally
        {
            _automation.Dispose();
        }
    }

    private AutomationElement FindByAutomationId(string automationId)
    {
        return MainWindow.FindFirstDescendant(condition => condition.ByAutomationId(automationId))
            ?? throw new InvalidOperationException($"Не найден элемент AutomationId={automationId}.");
    }

    private AutomationElement FindByName(string name)
    {
        return MainWindow.FindFirstDescendant(condition => condition.ByName(name))
            ?? throw new InvalidOperationException($"Не найден элемент Name={name}.");
    }

    private AutomationElement FindByText(string text)
    {
        return MainWindow.FindFirstDescendant(condition => condition.ByText(text))
            ?? throw new InvalidOperationException($"Не найден элемент с текстом «{text}».");
    }

    private Window MainWindow =>
        _app.GetMainWindow(_automation)
        ?? throw new InvalidOperationException("Не найдено главное окно приложения.");

    private void EnterPassword(string password)
    {
        var passwordBox = FindByName("PasswordInput");
        passwordBox.Click();
        Keyboard.Type(password);
    }

    private void RunAndCapture(string testName, Action test)
    {
        try
        {
            test();
        }
        finally
        {
            var screenshotDirectory = Path.Combine(AppContext.BaseDirectory, "Screenshots");
            Directory.CreateDirectory(screenshotDirectory);
            var screenshotPath = Path.Combine(
                screenshotDirectory,
                $"{testName}_{DateTime.UtcNow:yyyyMMddHHmmssfff}.png");

            MainWindow.Capture().Save(screenshotPath, ImageFormat.Png);
        }
    }
}
