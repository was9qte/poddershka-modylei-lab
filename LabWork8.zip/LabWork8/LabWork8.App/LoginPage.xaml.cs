using System.Windows;
using System.Windows.Controls;

namespace LabWork8;

public partial class LoginPage : Page
{
    public LoginPage()
    {
        InitializeComponent();
    }

    private void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        var login = LoginInput.Text.Trim();
        var password = PasswordInput.Password;

        if (string.IsNullOrWhiteSpace(login))
        {
            ShowError("Введите логин.");
            return;
        }

        if (string.IsNullOrEmpty(password))
        {
            ShowError("Введите пароль.");
            return;
        }

        var user = UserAccounts.FindByLogin(login);
        if (user is null)
        {
            ShowError("Пользователь с таким логином не найден.");
            return;
        }

        if (!string.Equals(user.Password, password, StringComparison.Ordinal))
        {
            ShowError("Неверный пароль.");
            return;
        }

        NavigationService?.Navigate(new WelcomePage(login, user.Role));
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
    }
}
