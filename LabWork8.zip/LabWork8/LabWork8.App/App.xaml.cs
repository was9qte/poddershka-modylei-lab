using System.Windows;

namespace LabWork8;

public partial class App : Application
{
}
