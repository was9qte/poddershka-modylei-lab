namespace LabWork8;

internal sealed record UserAccount(string Password, string Role);

internal static class UserAccounts
{
    private static readonly IReadOnlyDictionary<string, UserAccount> Accounts =
        new Dictionary<string, UserAccount>(StringComparer.Ordinal)
        {
            ["admin"] = new("admin123", "Администратор"),
            ["student"] = new("student123", "Студент")
        };

    public static UserAccount? FindByLogin(string login)
    {
        return Accounts.GetValueOrDefault(login);
    }
}
