using System.Windows;

namespace LabWork8;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        ContentFrame.Navigate(new LoginPage());
    }
}
