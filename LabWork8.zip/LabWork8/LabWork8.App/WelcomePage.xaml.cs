using System.Windows.Controls;

namespace LabWork8;

public partial class WelcomePage : Page
{
    public WelcomePage(string login, string role)
    {
        InitializeComponent();
        WelcomeMessage.Text = $"Добро пожаловать, {login}, ваша роль - {role}";
    }
}
