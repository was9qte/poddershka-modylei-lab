using FluentAssertions;
using Moq;
using OrderProcessing.Interfaces;
using OrderProcessing.Models;
using OrderProcessing.Services;
using Xunit;

namespace OrderProcessing.Tests;

public class OrderServiceTests
{
    private readonly Mock<IOrderRepository> _orders = new();
    private readonly Mock<ICustomerRepository> _customers = new();
    private readonly Mock<IMessageBus> _bus = new();
    private readonly OrderService _service;

    public OrderServiceTests()
    {
        _service = new OrderService(_orders.Object, _customers.Object, _bus.Object);
    }

    [Fact]
    public async Task CreateOrderAsync_WhenCustomerExists_CreatesOrderAndPublishesEvent()
    {
        var customerId = Guid.NewGuid();
        _customers.Setup(x => x.GetByIdAsync(customerId))
            .ReturnsAsync(new Customer { Id = customerId, Name = "Иван", Email = "ivan@example.com" });
        _orders.Setup(x => x.AddAsync(It.IsAny<Order>())).Returns(Task.CompletedTask);
        _bus.Setup(x => x.PublishAsync("order.created", It.IsAny<object>())).Returns(Task.CompletedTask);

        var result = await _service.CreateOrderAsync(customerId, 1250m);

        result.CustomerId.Should().Be(customerId);
        result.TotalAmount.Should().Be(1250m);
        result.Status.Should().Be(OrderStatus.Pending);
        _orders.Verify(x => x.AddAsync(It.Is<Order>(o => o.CustomerId == customerId && o.TotalAmount == 1250m)), Times.Once);
        _bus.Verify(x => x.PublishAsync("order.created", It.IsAny<object>()), Times.Once);
    }

    [Fact]
    public async Task CreateOrderAsync_WhenCustomerMissing_ThrowsAndDoesNotCreateOrder()
    {
        var customerId = Guid.NewGuid();
        _customers.Setup(x => x.GetByIdAsync(customerId)).ReturnsAsync((Customer?)null);

        var act = async () => await _service.CreateOrderAsync(customerId, 100m);

        await act.Should().ThrowAsync<InvalidOperationException>().WithMessage("Клиент не найден.");
        _orders.Verify(x => x.AddAsync(It.IsAny<Order>()), Times.Never);
        _bus.Verify(x => x.PublishAsync(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
    }

    [Fact]
    public async Task ConfirmPaymentAsync_WhenOrderExists_ChangesStatusAndPublishesEvent()
    {
        var orderId = Guid.NewGuid();
        var order = new Order { Id = orderId, Status = OrderStatus.Pending };
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync(order);
        _orders.Setup(x => x.UpdateAsync(order)).Returns(Task.CompletedTask);
        _bus.Setup(x => x.PublishAsync("order.paid", It.IsAny<object>())).Returns(Task.CompletedTask);

        await _service.ConfirmPaymentAsync(orderId);

        order.Status.Should().Be(OrderStatus.Paid);
        _orders.Verify(x => x.UpdateAsync(order), Times.Once);
        _bus.Verify(x => x.PublishAsync("order.paid", It.IsAny<object>()), Times.Once);
    }

    [Fact]
    public async Task ConfirmPaymentAsync_WhenOrderMissing_Throws()
    {
        var orderId = Guid.NewGuid();
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync((Order?)null);

        var act = async () => await _service.ConfirmPaymentAsync(orderId);

        await act.Should().ThrowAsync<InvalidOperationException>().WithMessage("Заказ не найден.");
        _orders.Verify(x => x.UpdateAsync(It.IsAny<Order>()), Times.Never);
        _bus.Verify(x => x.PublishAsync(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
    }

    [Fact]
    public async Task CancelOrderAsync_WhenOrderExists_CancelsAndPublishesEvent()
    {
        var orderId = Guid.NewGuid();
        var order = new Order { Id = orderId, Status = OrderStatus.Pending };
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync(order);
        _orders.Setup(x => x.UpdateAsync(order)).Returns(Task.CompletedTask);
        _bus.Setup(x => x.PublishAsync("order.cancelled", It.IsAny<object>())).Returns(Task.CompletedTask);

        await _service.CancelOrderAsync(orderId);

        order.Status.Should().Be(OrderStatus.Cancelled);
        _orders.Verify(x => x.UpdateAsync(order), Times.Once);
        _bus.Verify(x => x.PublishAsync("order.cancelled", It.IsAny<object>()), Times.Once);
    }

    [Fact]
    public async Task CancelOrderAsync_WhenOrderMissing_Throws()
    {
        var orderId = Guid.NewGuid();
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync((Order?)null);

        var act = async () => await _service.CancelOrderAsync(orderId);

        await act.Should().ThrowAsync<InvalidOperationException>().WithMessage("Заказ не найден.");
        _orders.Verify(x => x.UpdateAsync(It.IsAny<Order>()), Times.Never);
        _bus.Verify(x => x.PublishAsync(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
    }

    [Fact]
    public async Task ShipOrderAsync_WhenOrderPaid_ShipsAndPublishesEvent()
    {
        var orderId = Guid.NewGuid();
        var order = new Order { Id = orderId, Status = OrderStatus.Paid };
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync(order);
        _orders.Setup(x => x.UpdateAsync(order)).Returns(Task.CompletedTask);
        _bus.Setup(x => x.PublishAsync("order.shipped", It.IsAny<object>())).Returns(Task.CompletedTask);

        await _service.ShipOrderAsync(orderId);

        order.Status.Should().Be(OrderStatus.Shipped);
        _orders.Verify(x => x.UpdateAsync(order), Times.Once);
        _bus.Verify(x => x.PublishAsync("order.shipped", It.IsAny<object>()), Times.Once);
    }

    [Theory]
    [InlineData(OrderStatus.Pending)]
    [InlineData(OrderStatus.Cancelled)]
    [InlineData(OrderStatus.Shipped)]
    public async Task ShipOrderAsync_WhenOrderIsNotPaid_Throws(OrderStatus status)
    {
        var orderId = Guid.NewGuid();
        var order = new Order { Id = orderId, Status = status };
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync(order);

        var act = async () => await _service.ShipOrderAsync(orderId);

        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("Отправить можно только оплаченные заказы.");
        _orders.Verify(x => x.UpdateAsync(It.IsAny<Order>()), Times.Never);
        _bus.Verify(x => x.PublishAsync(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
    }

    [Fact]
    public async Task ShipOrderAsync_WhenOrderMissing_Throws()
    {
        var orderId = Guid.NewGuid();
        _orders.Setup(x => x.GetByIdAsync(orderId)).ReturnsAsync((Order?)null);

        var act = async () => await _service.ShipOrderAsync(orderId);

        await act.Should().ThrowAsync<InvalidOperationException>().WithMessage("Заказ не найден.");
        _orders.Verify(x => x.UpdateAsync(It.IsAny<Order>()), Times.Never);
        _bus.Verify(x => x.PublishAsync(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
    }
}
